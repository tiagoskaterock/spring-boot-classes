package tiago.lemes.exercicios_spring_boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExerciciosSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExerciciosSpringBootApplication.class, args);
	}

}
