package tiago.lemes.exercicios_spring_boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExerciciosSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
